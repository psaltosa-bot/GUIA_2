# GUÍA RÁPIDA PARA EL EXAMEN — MODELS, VIEWS Y MAIN

Esta guía acompaña al proyecto `Proyecto_Ventas`. La idea del examen es que el profesor indique un método (normalmente en `models.py`) y tú completes su uso en `views.py` y `main.py`.

## 1. Qué hace cada archivo

- **models.py**: define los objetos y sus reglas. Ejemplos: `Cliente.nombre_completo()`, `Producto.con_iva()`, `Producto.stock_bajo()`, `Venta.calcular_total()`.
- **views.py**: los controladores gestionan listas, validan, buscan y guardan. Aquí se implementa la lógica que conecta los modelos con los datos. Ejemplos: `clientes_por_ciudad()`, `con_stock_bajo()`, `ventas_por_cliente()`.
- **main.py**: interfaz de consola. Pide datos, llama al controlador y muestra el resultado. Para que una función nueva se pueda elegir, se agrega al menú correspondiente.

Flujo típico: **main → controlador en views → modelo en models → resultado de vuelta a views → main lo imprime**.

## 2. Receta para adaptar cualquier método

1. Lee qué recibe el método y qué devuelve (`return`).
2. En `models.py`, crea o adapta el método pedido sin mezclar `input()` ni `print()` con la lógica del modelo.
3. En `views.py`, crea el método del controlador. Obtén datos de `self.lista`, usa los objetos/modelos y devuelve el resultado.
4. En `main.py`, crea una función de pantalla que llame al controlador y presente la respuesta.
5. Agrega esa función al diccionario de menú: por ejemplo, `MENU_CLIENTES`, `MENU_PRODUCTOS` o `MENU_VENTAS`.
6. Prueba el caso normal y los casos vacíos/no encontrados.

## 3. Tipos de devolución: qué hacer en main

| Lo que devuelve | Ejemplo | Cómo mostrarlo |
|---|---|---|
| Un objeto o `None` | `obtener(id)` | `if objeto is None: ... else: print(objeto)` |
| Una lista | `buscar(texto)` | Recorrerla; si está vacía, informar que no hay resultados |
| Un diccionario | `clientes_por_ciudad()` | `for clave, valor in resultado.items(): ...` |
| Un número | `total_vendido()` | `print(f"Total: ${resultado:.2f}")` |
| Un texto o `None` | `comprobante(id)` | Imprimir el texto o avisar que no existe |
| Una tupla `(exito, mensaje)` | `crear(datos)` | `mostrar_resultado(*controlador.crear(datos))` |
| `True`/`False` | método de validación/regla | `if resultado: ... else: ...` |

**Ojo:** `return` devuelve un valor al código que llamó al método; `print()` solo lo muestra en pantalla. No son lo mismo.

## 4. Plantillas para el examen

### A. Método de modelo que devuelve un valor calculado

```python
class Producto:
    def precio_con_descuento(self, porcentaje):
        return round(self.precio * (1 - porcentaje / 100), 2)
```

Uso desde `main.py` si ya tienes un objeto `producto`:

```python
print(f"Precio con descuento: ${producto.precio_con_descuento(10):.2f}")
```

### B. Método del controlador que devuelve una lista filtrada

```python
def buscar_por_criterio(self, criterio):
    encontrados = []
    criterio = criterio.strip().lower()
    for objeto in self.lista:
        if criterio in objeto.nombre.lower():
            encontrados.append(objeto)
    return encontrados
```

En `main.py`:

```python
def ver_por_criterio():
    resultado = productos.buscar_por_criterio(input("Criterio: "))
    mostrar_lista(resultado, "No hay coincidencias.")
    pausa()
```

Luego en el menú adecuado:

```python
MENU_PRODUCTOS = {
    # ... opciones que ya existen ...
    "7": ("Buscar por criterio", ver_por_criterio),
    "0": ("Volver", None),
}
```

### C. Método del controlador que devuelve un diccionario agrupado

```python
def agrupar_por_ciudad(self):
    grupos = {}
    for cliente in self.lista:
        ciudad = cliente.ciudad or "Sin ciudad"
        grupos.setdefault(ciudad, []).append(cliente.nombre_completo())
    return grupos
```

En `main.py`:

```python
def ver_agrupados():
    grupos = clientes.agrupar_por_ciudad()
    if not grupos:
        imprimir_info("No hay datos.")
    for clave, elementos in grupos.items():
        print(f"{clave}: {', '.join(elementos)}")
    pausa()
```

### D. Método que devuelve `(éxito, mensaje)`

Este proyecto usa ese patrón en `crear`, `actualizar` y `eliminar`:

```python
return False, "Explicación del error"
# o
return True, "Operación completada"
```

En `main.py` ya existe la ayuda:

```python
mostrar_resultado(*clientes.actualizar(id_cliente, cambios))
```

El `*` separa la tupla en dos argumentos: `exito` y `mensaje`.

## 5. Cómo pasar datos entre main y views

En `main.py`, construye un diccionario con lo que escribió el usuario:

```python
datos = {"nombre": input("Nombre: "), "ciudad": input("Ciudad: ")}
resultado = clientes.metodo_nuevo(datos)
```

En `views.py`, recibe ese diccionario como parámetro y accede con `datos["nombre"]` o, para un campo opcional, `datos.get("ciudad", "")`.

No pongas `input()` dentro del controlador, salvo que el profesor lo pida explícitamente. El controlador debería recibir datos y devolver resultados.

## 6. Patrones que ya aparecen en este proyecto

- Buscar por texto: `buscar()` devuelve una **lista**.
- Buscar por ID: `obtener()` devuelve un **objeto o `None`**.
- Obtener todas las filas: `leer()` devuelve una **lista**.
- Operación CRUD: `crear/actualizar/eliminar()` devuelve **(bool, mensaje)**.
- Agrupar registros: `clientes_por_ciudad()` y `ventas_por_cliente()` devuelven **diccionarios**.
- Calcular un total: `total_vendido()` devuelve un **número**.
- Mostrar comprobante: `comprobante()` devuelve **texto o `None`**.
- El menú usa diccionarios de `"tecla": ("descripción", función)`.

## 7. Errores frecuentes en el examen

1. Crear el método en `models.py` y olvidar implementarlo en el controlador de `views.py`.
2. Crear la función en `main.py` pero olvidar agregarla al diccionario del menú.
3. Usar `print()` en lugar de `return`, y luego intentar guardar el resultado en una variable.
4. Tratar un diccionario como lista: para recorrer pares usa `.items()`.
5. No controlar una lista vacía o un `None`.
6. Cambiar el nombre del método en un archivo y no actualizar las llamadas en los demás.
7. Olvidar `self` en métodos de instancia.
8. Si se altera stock o ventas, olvidar guardar con el método `guardar()` correspondiente.
9. Añadir un método abstracto a `CrudBase` sin implementarlo en todos los controladores concretos.

## 8. Mini-ejercicios para practicar

Intenta implementarlos primero sin mirar el proyecto resuelto:

1. `Cliente.iniciales()` → devuelve iniciales, por ejemplo `"PD"`.
2. `Producto.valor_inventario()` → devuelve `precio * stock`.
3. `ProductoController.sin_stock()` → devuelve una lista de productos cuyo stock sea `0`.
4. `ClienteController.buscar_por_ciudad(ciudad)` → devuelve una lista de clientes de esa ciudad, ignorando mayúsculas/minúsculas.
5. `VentaController.ventas_de_cliente(id_cliente)` → devuelve una lista de ventas del cliente.
6. Mostrar cada resultado desde `main.py`, incluyendo un mensaje cuando no haya resultados, y agregar una opción al menú si corresponde.

### Solución orientativa para uno de los ejercicios

En `models.py`, dentro de `Producto`:

```python
def valor_inventario(self):
    return round(self.precio * self.stock, 2)
```

En `views.py`, dentro de `ProductoController`:

```python
def sin_stock(self):
    resultado = []
    for producto in self.lista:
        if producto.stock == 0:
            resultado.append(producto)
    return resultado
```

En `main.py`:

```python
def ver_productos_sin_stock():
    imprimir_titulo("PRODUCTOS SIN STOCK")
    mostrar_lista(productos.sin_stock(), "Todos los productos tienen stock.")
    pausa()
```

Y agregar al `MENU_PRODUCTOS` una entrada como:

```python
"7": ("Productos sin stock", ver_productos_sin_stock),
```

## 9. Antes de entregar

- [ ] El nombre del método coincide exactamente en todos los archivos.
- [ ] Los parámetros coinciden con la llamada.
- [ ] El método devuelve el tipo de dato esperado.
- [ ] `main.py` controla lista vacía, `None` o error.
- [ ] La opción nueva está en el menú correcto.
- [ ] Si cambian datos persistentes, se guarda el JSON.
- [ ] Ejecuta `main.py` y prueba al menos un caso válido y uno límite.

## Método agregado: devolución parcial o total de una venta

Se agregó una opción nueva en el menú de ventas para devolver unidades y reintegrarlas al stock.

### 1. Modelo (`models.py`)
En la clase `Venta`, el método `calcular_devolucion(cantidad)` calcula el importe a devolver usando el precio unitario. Devuelve `0.0` si la cantidad no es válida.

### 2. Controlador (`views.py`)
En `VentaController`, el método `devolver(id_venta, cantidad)`:
- busca la venta por su ID;
- valida que la cantidad sea un entero positivo y no supere la cantidad comprada;
- calcula el importe a devolver;
- aumenta el stock del producto;
- si la devolución es parcial, reduce la cantidad de la venta;
- si se devuelve toda la cantidad, elimina esa venta del registro;
- guarda los cambios en los archivos JSON;
- devuelve una tupla `(True/False, mensaje)`.

### 3. Vista/menú (`main.py`)
La función `devolver_venta()` pide el ID y la cantidad, confirma la operación y muestra el resultado. Se añadió la opción **5. Devolución parcial o total** al menú de ventas.

### Flujo para recordar en el examen
`main.py` recoge los datos → `views.py` valida y coordina la operación → `models.py` calcula el importe → `views.py` actualiza stock y venta → `main.py` muestra el mensaje.

**Diferencia importante:** `anular_venta()` elimina toda la venta; `devolver_venta()` permite devolver solo algunas unidades o todas.
